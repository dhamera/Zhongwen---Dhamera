# Memória Mandarim — versão independente

App de flashcards com repetição espaçada, com áudio e progresso salvo no próprio navegador
(não depende de conta Claude). Pronto para publicar de graça no GitHub Pages.

## O que tem nessa versão

- **10 lições de história e cultura**, logo na tela inicial, antes dos flashcards: as raízes do mandarim (ossos oraculares, ~1250 a.C.), a unificação da escrita por Qin Shi Huang, por que existem tons, a história do pinyin (criado em 1958), as dinastias, Confúcio e o conceito de "guanxi"/"face", números e superstições, a história de Xangai (de vila pesqueira a Pudong), e a Reforma e Abertura de 1978. Cada lição tem uma "curiosidade" extra ao final.
- **200 cartões de vocabulário** em 15 decks (aulas reais + vida prática em Xangai: restaurante, mercado, táxi/carro).
- **Áudio automático** ao virar o cartão, usando a voz nativa do navegador.
- **Repetição espaçada** com prazos calibrados (Esqueci/Difícil/Bom/Fácil sempre crescentes).
- **Fato do dia** rotativo na tela inicial, e um selo "✓ dominado" quando você termina um deck inteiro.
- Progresso salvo automaticamente no navegador de cada pessoa (localStorage), sem depender de conta nenhuma.

## Como publicar (sem usar linha de comando)

1. Crie uma conta gratuita em https://github.com (se ainda não tiver).
2. Clique no "+" no canto superior direito → "New repository".
   - Nome sugerido: `mandarim-srs`
   - Marque como **Public**
   - Não marque "Add a README" (já vamos subir os arquivos)
   - Clique em "Create repository".
3. Na página do repositório recém-criado, clique em "uploading an existing file"
   (ou "Add file" → "Upload files").
4. Arraste estes 5 arquivos para a janela do navegador:
   - index.html
   - manifest.json
   - sw.js
   - icon-192.png
   - icon-512.png
5. Clique em "Commit changes".
6. Vá em **Settings** (do repositório) → **Pages** (menu lateral esquerdo).
7. Em "Build and deployment" → "Source", selecione **Deploy from a branch**.
8. Em "Branch", selecione **main** e a pasta **/ (root)** → **Save**.
9. Espere cerca de 1 minuto. Recarregue a página de Settings → Pages: vai aparecer
   um link tipo `https://SEU-USUARIO.github.io/mandarim-srs/`.
10. Abra esse link no celular (Safari no iPhone ou Chrome no Android).
11. Toque no menu de compartilhar/opções → **"Adicionar à Tela de Início"**
    (iPhone) ou **"Instalar app"** (Android). Pronto: ícone próprio, abre em tela cheia.
12. Mande o mesmo link para sua esposa e amigos — cada um instala no aparelho
    da mesma forma, e o progresso de cada pessoa fica salvo separadamente,
    no próprio celular de cada um.

## Como atualizar depois (adicionar palavras, corrigir bugs, novas features)

Você não precisa reenviar nada pra ninguém. O link continua o mesmo pra sempre.

1. Peça pro Claude alterar o `index.html` (ou altere você mesmo).
2. No GitHub, vá até o arquivo `index.html` do repositório → ícone de lápis
   (editar) → cole o conteúdo novo → "Commit changes". Ou repita o passo 4
   de "Add file → Upload files" e arraste o arquivo novo por cima do antigo.
3. O GitHub Pages reconstrói sozinho em ~1 minuto.
4. Na próxima vez que cada pessoa abrir o app instalado no celular, ela já
   recebe a versão nova automaticamente — sem instalar de novo, sem perder
   o progresso.

O app foi construído com o service worker (`sw.js`) configurado no modo
"internet primeiro": ele sempre busca a versão mais recente quando há sinal,
e só usa a cópia salva no aparelho se a pessoa estiver sem internet. Por isso
as atualizações chegam sozinhas.

**Único cuidado:** nunca mude o valor de `STORAGE_KEY` dentro do `index.html`
(está como `'srs-state-v1'`). Se esse nome mudar, o app não vai mais achar
o progresso salvo de ninguém — mesmo que os dados continuem lá.

## Importante

- O progresso é salvo no navegador de cada aparelho (localStorage). Ele **não**
  sincroniza entre o celular e o computador, e **não** é o mesmo progresso
  que você já tinha na versão publicada dentro do Claude — é um começo novo.
- Se limpar os dados/cache do navegador, o progresso se perde. Não existe
  backup automático nesta versão (posso adicionar exportar/importar depois,
  se quiser).
- Para atualizar o app no futuro (novas palavras, correções), é só repetir o
  passo 4 (upload dos arquivos) substituindo os antigos — o link continua o
  mesmo.
